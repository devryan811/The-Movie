//
//  HomePopularCollectionCell.swift
//  The Movie
//
//  Created by Ryan Aditya on 26/03/22.
//

import Foundation
import UIKit
import RxCocoa
import RxSwift

class HomePopularCollectionCell: BaseCollectionCell {
    
    private var movieListViewModel: MovieListViewModel!
    private let disposeBag = DisposeBag()
    
    override func sizeCollection() -> CGSize {
        return size_home_other
    }
    
    override func registerCell() {
        self.collectionView.register(MovieCell.self, self.collectionView)
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        self.getListMovies()
    }
    
    // MARK: API
    private func getListMovies() {
        movieListViewModel = MovieListViewModel(endpoint: .popular
            , movieService: MovieStore.shared)
        
        movieListViewModel.movies.drive(onNext: {[weak self] (_) in
            self?.collectionView.reloadData()
        }).disposed(by: disposeBag)
        
        movieListViewModel.error.drive(onNext: {(error) in
            print(error?.description ?? "")
        }).disposed(by: disposeBag)
    }
    
}

extension HomePopularCollectionCell: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movieListViewModel.numberOfMovies
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: String(describing: MovieCell.self), for: indexPath) as? MovieCell else {
            fatalError()
        }
        if let viewModel = movieListViewModel.viewModelForMovie(at: indexPath.row) {
            cell.configure(viewModel: viewModel)
        }
        cell.detailButton = {
            print(indexPath.row)
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let viewModel = movieListViewModel.viewModelForMovie(at: indexPath.row) {
            let detailView = DetailViewController(viewModel: viewModel)
            UINavigationController.currentActiveNavigationController()?.pushViewController(detailView, animated: true)
        }
    }
    
}


extension HomePopularCollectionCell: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: marginTopCell, left: marginCell, bottom: marginCell, right: marginCell)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return paddingCell
    }
    
}

