//
//  GenreViewModel.swift
//  The Movie
//
//  Created by Ryan Aditya on 26/03/22.
//

import UIKit

struct GenreViewModel {
    
    private var genre: Genre
    
    init(genre: Genre) {
        self.genre = genre
    }
    
    var title: String {
        return genre.name
    }
    
}
