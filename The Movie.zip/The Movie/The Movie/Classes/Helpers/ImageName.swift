//
//  ImageName.swift
//  The Movie
//
//  Created by Ryan Aditya on 26/03/22.
//

import Foundation

let image_home_logo                         = "home_app_logo"
let image_home_navi_profile                 = "home_navi_profile"
let image_home_navi_search                  = "home_navi_search"
let image_home_section_more                 = "home_section_more"
let image_home_detail_more                  = "home_detail_more"
let image_home_category_1                   = "img_category_1"
let image_home_category_2                   = "img_category_2"

let image_detail_back                       = "detail_ic_back"
let image_detail_favorite                   = "detail_btn_fav"
let image_detail_ic_star_empty              = "detail_ic_star_empty"
let image_detail_ic_star_full               = "detail_ic_star_full"
let image_detail_ic_play                    = "detail_ic_play"
let image_detail_ic_play_white              = "detail_ic_play_white"

let image_detail_avatar                     = "default_avatar"
