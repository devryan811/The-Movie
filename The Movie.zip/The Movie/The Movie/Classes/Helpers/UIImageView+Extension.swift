//
//  UIImageView+Extension.swift
//  The Movie
//
//  Created by Ryan Aditya on 26/03/22.
//

import Foundation
import UIKit

extension UIImageView {
    
    func normalShadow() {
        self.layer.masksToBounds = false
        self.layer.shadowRadius = 4
        self.layer.shadowOpacity = 1
        self.layer.shadowColor = UIColor.gray.cgColor
        self.layer.shadowOffset = CGSize(width: 0, height:2)
    }
  
}
